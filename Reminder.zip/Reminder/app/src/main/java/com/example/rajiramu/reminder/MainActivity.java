package com.example.rajiramu.reminder;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;
import android.database.Cursor;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import static java.util.Calendar.HOUR;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

   private int rem_id=1;
   static String time;
    static SQLiteDatabase sqlitedb;
    public static final String DATABASE_NAME="ReminderDB";
    static public String message;
   static Button datepick,timepick;
  static EditText txttime,txtdate;
   static private int year,month,day,hour,minute;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       sqlitedb=openOrCreateDatabase(DATABASE_NAME,Context.MODE_PRIVATE,null);
        sqlitedb.execSQL("CREATE TABLE IF NOT EXISTS Reminder_table(Id INTEGER PRIMARY KEY AUTOINCREMENT,RemTask VARCHAR(255),RemTime VARCHAR(255) );");


        findViewById(R.id.addBtn).setOnClickListener(this);
        findViewById(R.id.delBtn).setOnClickListener(this);
        findViewById(R.id.viewBtn).setOnClickListener(this);



        datepick=findViewById(R.id.btn_date);
        timepick=findViewById(R.id.btn_time);
        txtdate=findViewById(R.id.in_date);
        txttime=findViewById(R.id.in_time);

        datepick.setOnClickListener(this);
        timepick.setOnClickListener(this);


    }
    @Override
    public void onClick(View view)
    {
     EditText editText=findViewById(R.id.editText);
     message=editText.getText().toString();
     EditText d1=findViewById(R.id.in_date);
     EditText t1=findViewById(R.id.in_time);
     Intent intent = new Intent(MainActivity.this,AlarmReceiver.class);
     intent.putExtra("TaskID",rem_id);
     intent.putExtra("Todo Tasks",editText.getText().toString());

     PendingIntent alarmIntent = PendingIntent.getBroadcast(MainActivity.this,0,intent,PendingIntent.FLAG_CANCEL_CURRENT);

        AlarmManager alarm = (AlarmManager) getSystemService(ALARM_SERVICE);

        switch(view.getId()) {
            case R.id.btn_date:
                final Calendar c = Calendar.getInstance();
                year = c.get(Calendar.YEAR);
                month = c.get(Calendar.MONTH);
                day = c.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int years,
                                                  int monthOfYear, int dayOfMonth) {

                                txtdate.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + years);
                                day=dayOfMonth;
                                month=monthOfYear+1;
                                year=years;

                            }
                        }, year, month, day);
                datePickerDialog.show();
                break;
            case R.id.btn_time:
                final Calendar c1 = Calendar.getInstance();
                hour = c1.get(Calendar.HOUR_OF_DAY);
                minute = c1.get(Calendar.MINUTE);

                // Launch Time Picker Dialog
                TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                        new TimePickerDialog.OnTimeSetListener() {

                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay,
                                                  int minutes) {

                                txttime.setText(hourOfDay + ":" + minutes);
                                hour=hourOfDay;
                                minute=minutes;
                            }
                        }, hour, minute, false);
                timePickerDialog.show();
                break;

            case R.id.addBtn:
                String task = editText.getText().toString();
                time= String.valueOf(day)+"-"+String.valueOf(month)+"-"+String.valueOf(year);
                time = time +" "+ String.valueOf(hour) + ":" + String.valueOf(minute);

                Calendar startTime = Calendar.getInstance();
                startTime.set(Calendar.HOUR_OF_DAY, hour);
                startTime.set(Calendar.MINUTE, minute);
                startTime.set(Calendar.SECOND, 0);
                long alarmStartTime = startTime.getTimeInMillis();
                alarm.set(AlarmManager.RTC_WAKEUP, alarmStartTime, alarmIntent);
                if (task.equals("")) {
                    Toast.makeText(this, "Task cannot be empty", Toast.LENGTH_SHORT).show();
                    return;
                } else {
                    sqlitedb.execSQL("Insert Into Reminder_table(RemTask,RemTime)VALUES('" + task + "','" + time + "');");
                    Toast.makeText(this, "Reminder added", Toast.LENGTH_SHORT).show();
                }

                break;

            case R.id.delBtn:
                String task1 = editText.getText().toString();
                if(task1.equals("")) {
                    Toast.makeText(this, "Task cannot be empty", Toast.LENGTH_SHORT).show();
                    return;
                }
                String WhereClause=" RemTask=? ";
                String Whereargs[]=new String[]{message};
                sqlitedb.delete("Reminder_table",WhereClause,Whereargs);
                Toast.makeText(this, "Cancelled..", Toast.LENGTH_SHORT).show();
                break;


            case R.id.viewBtn:

                startActivity(new Intent(MainActivity.this,Main2Activity.class));

                break;

        }



        }

}
