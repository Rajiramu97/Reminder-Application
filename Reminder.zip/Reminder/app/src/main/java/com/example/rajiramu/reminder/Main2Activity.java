package com.example.rajiramu.reminder;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        ListView lv = (ListView) findViewById(R.id.list_view);

        Cursor l= MainActivity.sqlitedb.rawQuery("Select * from Reminder_table", null);
        if (l.getCount() == 0) {
            Toast.makeText(this, "No Reminders!!", Toast.LENGTH_SHORT).show();
            return;
        }
        ArrayList<String> todo = new ArrayList<String>();
        StringBuffer buffer = new StringBuffer();
        buffer.append("ToDo Tasks:");
        todo.add(buffer.toString());
        while (l.moveToNext()) {
            buffer.delete(0,buffer.length());
            buffer.append("\n" + l.getString(1));
            buffer.append(" at" + "  " + l.getString(2));
            todo.add(buffer.toString());

        }


         ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_list_item_1, todo);
        lv.setAdapter(arrayAdapter);

    }
}
